@extends('layouts.app')

@section('content')
    <!-- Your specific content for the admin page -->
    <div id="app">
        <admin-component></admin-component>
    </div>
@endsection
    
